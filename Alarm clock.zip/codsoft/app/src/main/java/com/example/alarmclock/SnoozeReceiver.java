package com.example.alarmclock;

public class SnoozeReceiver {
}
